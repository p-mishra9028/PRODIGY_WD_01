// Add smooth scrolling effect to navigation links
document.querySelectorAll('header nav ul li a').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
      e.preventDefault();
  
      const target = document.querySelector(this.getAttribute('href'));
  
      window.scrollTo({
        top: target.offsetTop - 70, // Adjusted for fixed header height
        behavior: 'smooth'
      });
    });
  });
  
  // Change navbar style on scroll
  window.addEventListener('scroll', function() {
    var header = document.querySelector('header');
    if (window.scrollY > 0) {
      header.classList.add('scroll-active');
    } else {
      header.classList.remove('scroll-active');
    }
  
    // Add 'show' class to sections when they are in view
    document.querySelectorAll('.section').forEach(section => {
      const sectionTop = section.offsetTop;
      const sectionHeight = section.clientHeight;
      if (window.pageYOffset > sectionTop - window.innerHeight + sectionHeight / 2) {
        section.classList.add('show');
      }
    });
  });
  